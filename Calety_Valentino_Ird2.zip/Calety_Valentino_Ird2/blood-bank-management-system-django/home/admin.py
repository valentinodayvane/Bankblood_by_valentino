from django.contrib import admin
from .models import HomePageSlider,HomePageBody


admin.site.register(HomePageSlider)
admin.site.register(HomePageBody)




